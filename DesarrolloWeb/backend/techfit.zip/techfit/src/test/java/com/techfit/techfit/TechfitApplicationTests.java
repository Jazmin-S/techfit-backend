package com.techfit.techfit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechfitApplicationTests {

	@Test
	void contextLoads() {
	}

}
